// //从basic.js移植
// let cards = document.querySelectorAll('.container .card');

// cards.forEach(card => {
//     card.addEventListener('click', function() {
//         // card.classList.remove('locked');
//         // card.classList.add('unlocked');
//     });
// });

//
// window.resizeTo(768, 600); 
